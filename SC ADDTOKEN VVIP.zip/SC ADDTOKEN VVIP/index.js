const { Telegraf } = require('telegraf');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const botToken = '7500540171:AAEhz-3YBfL8gxeRcMoZh7MNg2kqjJaxKZM';
const adminId = '6647303766';
const github = {
  token: 'ghp',
  repoOwner: '',
  repoName: '',
  filePath: ''
};

const bot = new Telegraf(botToken);
const roleFile = path.join(__dirname, 'jsiz8u728.json');
if (!fs.existsSync(roleFile)) fs.writeFileSync(roleFile, JSON.stringify({ owners: [], moderators: [], resellers: [] }, null, 2));

function loadRoles() {
  return JSON.parse(fs.readFileSync(roleFile));
}
function saveRoles(data) {
  fs.writeFileSync(roleFile, JSON.stringify(data, null, 2));
}
function isAdmin(id) {
  return id.toString() === adminId.toString();
}
function isModerator(id) {
  const { moderators } = loadRoles();
  return moderators.includes(id.toString()) || isAdmin(id);
}
function isOwner(id) {
  const { owners } = loadRoles();
  return owners.includes(id.toString()) || isModerator(id);
}
function isReseller(id) {
  const { resellers } = loadRoles();
  return resellers.includes(id.toString()) || isOwner(id);
}
function addRole(type, id) {
  const roles = loadRoles();
  if (!roles[type].includes(id)) {
    roles[type].push(id);
    saveRoles(roles);
  }
}
function removeRole(type, id) {
  const roles = loadRoles();
  roles[type] = roles[type].filter(i => i !== id);
  saveRoles(roles);
}

const baseUrl = `https://api.github.com/repos/${github.repoOwner}/${github.repoName}/contents/${github.filePath}`;
const headers = {
  Authorization: `token ${github.token}`,
  'Accept': 'application/vnd.github.v3+json'
};

async function getFileContent() {
  try {
    const { data } = await axios.get(baseUrl, { headers });
    let content = Buffer.from(data.content, 'base64').toString('utf8');
    let parsed = JSON.parse(content);
    return { content: parsed.tokens || [], sha: data.sha };
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return { content: [], sha: null };
    }
    throw new Error("Gagal mengambil data dari GitHub.");
  }
}

async function updateFileContent(newContent, sha) {
  const payload = {
    message: "Update tokens",
    content: Buffer.from(JSON.stringify({ tokens: newContent }, null, 2)).toString('base64'),
    sha: sha || undefined,
  };
  await axios.put(baseUrl, payload, { headers });
}

async function addToken(token) {
  const { content, sha } = await getFileContent();
  if (content.includes(token)) throw new Error("Token sudah ada.");
  content.push(token);
  await updateFileContent(content, sha);
}
async function deleteToken(token) {
  const { content, sha } = await getFileContent();
  const newContent = content.filter(t => t !== token);
  await updateFileContent(newContent, sha);
}
async function getTokens() {
  const { content } = await getFileContent();
  return content;
}

// Start Command
bot.start(async (ctx) => {
  const chatId = ctx.chat.id;
  const ownerLink = 'https://t.me/SanzsTzyy';
  const channelLink = 'https://t.me/VortharionCh';

  const text = `
\`\`\`
-#- ======[ Feature Bot ]===== -#-

≈≈≈≈≈[ Database ]≈≈≈≈≈
-#- /addtoken <token_bot>
-#- /deltoken <token_bot>
-#- /listtoken 

≈≈≈≈≈[ Reseller ]≈≈≈≈≈
-#- /addres <user_id>
-#- /delres <user_id>

≈≈≈≈≈[ Owner ]≈≈≈≈≈
-#- /addown <user_id>
-#- /delown <user_id>

≈≈≈≈≈[ Moderator ]≈≈≈≈≈
-#- /addmod <user_id>
-#- /delmod <user_id>
\`\`\`
©Vortharion Crasher`;

  await ctx.telegram.sendVideo(chatId, "https://n.uguu.se/NMPZfYvl.mp4", {
    caption: text,
    parse_mode: "MarkdownV2",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "👤 Owner", url: ownerLink },
          { text: "ℹ️ Info Channel", url: channelLink }
        ]
      ]
    }
  });
});

// Command Handlers
bot.command('addtoken', async (ctx) => {
  if (!isReseller(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addtoken [token]");
  try {
    await addToken(args[1]);
    ctx.reply("✅ Token ditambahkan.");
  } catch (err) {
    ctx.reply("⚠️ " + err.message);
  }
});
bot.command('deltoken', async (ctx) => {
  if (!isReseller(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /deltoken [token]");
  try {
    await deleteToken(args[1]);
    ctx.reply("✅ Token dihapus.");
  } catch (err) {
    ctx.reply("⚠️ Gagal menghapus token.");
  }
});
bot.command('listtoken', async (ctx) => {
  if (!isModerator(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  try {
    const tokens = await getTokens();
    if (tokens.length === 0) return ctx.reply("Tidak ada token.");
    const msg = tokens.map((t, i) => {
      const masked = t.length > 10 ? `${t.slice(0, 5)}*****${t.slice(-5)}` : `${t.slice(0, 2)}*****${t.slice(-2)}`;
      return `${i + 1}. \`${masked}\``;
    }).join('\n');
    ctx.reply(`Daftar Token (disamarkan):\n${msg}`, { parse_mode: "Markdown" });
  } catch {
    ctx.reply("⚠️ Gagal mengambil token.");
  }
});
bot.command('addres', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addres [user_id]");
  addRole('resellers', args[1]);
  ctx.reply("✅ Reseller ditambahkan.");
});
bot.command('delres', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delres [user_id]");
  removeRole('resellers', args[1]);
  ctx.reply("✅ Reseller dihapus.");
});
bot.command('addown', async (ctx) => {
  if (!isModerator(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addown [user_id]");
  addRole('owners', args[1]);
  ctx.reply("✅ Owner ditambahkan.");
});
bot.command('delown', async (ctx) => {
  if (!isModerator(ctx.from.id)) return ctx.reply("❌ Akses ditolak.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delown [user_id]");
  removeRole('owners', args[1]);
  ctx.reply("✅ Owner dihapus.");
});
bot.command('addmod', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply("❌ Akses hanya untuk admin.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /addmod [user_id]");
  addRole('moderators', args[1]);
  ctx.reply("✅ Moderator ditambahkan.");
});
bot.command('delmod', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply("❌ Akses hanya untuk admin.");
  const args = ctx.message.text.split(' ');
  if (args.length < 2) return ctx.reply("Format: /delmod [user_id]");
  removeRole('moderators', args[1]);
  ctx.reply("✅ Moderator dihapus.");
});

bot.launch();
console.log("Bot sedang berjalan...");